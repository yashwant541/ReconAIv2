"""Drive the whole web backend over HTTP with the Flask test client."""
import io
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import openpyxl
from run_local import build_app


def xlsx_offset_header():
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Ledger"
    ws["A1"] = "Internal ledger export"
    ws.append([]); ws.append([None, None, None])
    ws.append(["Invoice", "Vendor", "Amount"])
    for r in [["INV-1001", "Acme Corp", 1200.50], ["INV-1002", "Globex", 3400.00],
              ["INV-1003", "Initech", 1000.00]]:
        ws.append(r)
    buf = io.BytesIO(); wb.save(buf); return buf.getvalue()


def csv_right():
    return ("note: downloaded today\n"
            "Reference,Supplier,Total\n"
            "INV-1001,Acme Corp,1200.50\n"
            "INV-1002,Globex,3400.05\n"
            "INV-1003,Initech,1000.00\n").encode()


app = build_app()
c = app.test_client()

# 1. session
sid = c.post("/session").get_json()["session_id"]
print("session:", sid[:8], "…")

# 2. upload both sides
r = c.post("/upload", data={"sid": sid, "side": "left",
           "files": (io.BytesIO(xlsx_offset_header()), "ledger.xlsx")},
           content_type="multipart/form-data").get_json()
print("left tables:", [(t["table"], t["columns"], t["rows"]) for t in r["side_tables"]])
assert r["side_tables"][0]["columns"] == ["Invoice", "Vendor", "Amount"], "offset header via HTTP"

r = c.post("/upload", data={"sid": sid, "side": "right",
           "files": (io.BytesIO(csv_right()), "bank.csv")},
           content_type="multipart/form-data").get_json()
print("right tables:", [(t["table"], t["columns"], t["rows"]) for t in r["side_tables"]])

# 3. suggest mapping
sug = c.post("/suggest_mapping", json={"sid": sid}).get_json()
print("suggested fields:")
for f in sug["fields"]:
    print(f"   {f['name']:8s} {f['role']:5s} {f['dtype']:6s} "
          f"{f['left_source']} -> {f['right_source']} ({f['_confidence']})")
assert any(f["role"] == "key" for f in sug["fields"]), "a key was suggested"

# 4. reconcile with suggested fields + all tables included
body = {"sid": sid, "fields": sug["fields"],
        "included_left": [t["id"] for t in r["side_tables"]],  # right ids (harmless demo)
        "matching": {"fuzzy_enabled": True, "fuzzy_threshold": 85, "accept_threshold": 0.5}}
# use proper included ids per side:
body["included_left"] = None
body["included_right"] = None
res = c.post("/reconcile", json=body).get_json()
print("reconcile summary:", {k: res["summary"][k] for k in
      ("matched_pairs", "reconciled", "breaks", "unmatched_left", "unmatched_right")})
assert res["summary"]["matched_pairs"] == 3, "3 invoices matched over HTTP"

# 5. export
xl = c.get(f"/export?sid={sid}")
assert xl.status_code == 200 and xl.data[:2] == b"PK", "xlsx download"
print("export bytes:", len(xl.data))

c.post("/finish", json={"sid": sid})
print("\nBACKEND HTTP TEST PASSED")
