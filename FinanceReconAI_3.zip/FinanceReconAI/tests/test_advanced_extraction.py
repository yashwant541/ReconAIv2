"""Advanced extraction tests: offset headers, multi-table sheets, auto-mapping."""
import io
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import openpyxl
from financial_reconciliation import api
from financial_reconciliation.config.settings import EngineConfig
from financial_reconciliation.models.enums import Side

# ---- 1. Excel with a title/preamble, header on row 4, plus a SECOND table ----
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Statement"
ws["A1"] = "ACME BANK — Monthly Statement"
ws["A2"] = "Confidential"
# blank row 3
ws.append([])           # row after A2 content region; keep explicit below
ws2rows = [
    [None, None, None],
    ["Invoice", "Vendor", "Amount"],   # header (row ~4)
    ["INV-1001", "Acme Corp", 1200.50],
    ["INV-1002", "Globex", 3400.00],
    ["INV-1003", "Initech", 1000.00],
    [None, None, None],                # blank separator -> new table
    ["Fee Code", "Description", "Charge"],
    ["FEE-1", "Wire fee", 25.00],
    ["FEE-2", "FX fee", 12.50],
]
for r in ws2rows:
    ws.append(r)
buf = io.BytesIO(); wb.save(buf); xlsx_bytes = buf.getvalue()

print("Sheets:", api.list_sheets("statement.xlsx", xlsx_bytes))
ext = api.extract_tables("statement.xlsx", xlsx_bytes)
print(f"Detected {len(ext.document.tables)} tables on the sheet:")
for t in ext.document.tables:
    print(f"  - '{t.name}' cols={t.columns} rows={t.row_count}")

assert len(ext.document.tables) == 2, "should split the sheet into 2 tables"
t0 = ext.document.tables[0]
assert t0.columns == ["Invoice", "Vendor", "Amount"], f"header misdetected: {t0.columns}"
assert t0.row_count == 3, "should skip preamble + header, keep 3 data rows"
t1 = ext.document.tables[1]
assert t1.columns == ["Fee Code", "Description", "Charge"], f"2nd header wrong: {t1.columns}"
print("  -> offset header + multi-table detection OK")

# ---- 2. Profiling: infer types + key/value roles ----
profiles = api.profile_side([ext])
print("\nColumn profiles:")
for p in profiles:
    print(f"  {p.name:12s} dtype={p.dtype.value:7s} role={p.role.value:5s} "
          f"uniq={p.uniqueness:.2f} key_score={p.key_score:.2f}")
inv = next(p for p in profiles if p.name == "Invoice")
amt = next(p for p in profiles if p.name == "Amount")
assert inv.role.value == "key", "Invoice should be a key"
assert amt.dtype.value == "money", "Amount should be money"
print("  -> profiling OK")

# ---- 3. Auto-mapping across two sides (different column names) ----
# right side CSV with header offset by a note line and renamed columns
csv_text = ("Downloaded 2026-07-01\n"
            "Reference,Supplier,Total\n"
            "INV-1001,Acme Corporation,1200.50\n"
            "INV-1002,Globex,3400.00\n"
            "INV-1003,Initech,1000.00\n")
right_ext = api.extract_tables("bank.csv", csv_text.encode())
print("\nRight table cols:", right_ext.document.tables[0].columns,
      "rows:", right_ext.document.tables[0].row_count)
assert right_ext.document.tables[0].columns == ["Reference", "Supplier", "Total"]

suggested = api.suggest_mapping([ext], [right_ext])
print("\nSuggested mapping:")
for f in suggested:
    print(f"  {f['name']:10s} {f['role']:5s} {f['dtype']:7s} "
          f"L='{f['left_source']}' R='{f['right_source']}' conf={f.get('_confidence')}")
names = {f["left_source"]: f for f in suggested}
assert "Invoice" in names and names["Invoice"]["right_source"] == "Reference", "invoice->reference"
assert "Amount" in names and names["Amount"]["right_source"] == "Total", "amount->total"
assert any(f["role"] == "key" for f in suggested), "at least one key"
print("  -> auto-mapping OK")

# ---- 4. Full reconcile using the suggested mapping ----
config = EngineConfig.from_dict({"fields": suggested,
                                 "matching": {"fuzzy_enabled": True, "fuzzy_threshold": 80}})
kv_left = api.to_key_value_records([ext], config, Side.LEFT)
print("\nKey-value records (left):", [(r.key, {k: str(v) for k, v in r.values.items()})
                                      for r in kv_left][:2])
result = api.reconcile([ext], [right_ext], config)
print("Reconcile summary:", {k: result.summary[k] for k in
      ("matched_pairs", "reconciled", "breaks", "unmatched_left", "unmatched_right")})
# All 3 invoices should MATCH (none unmatched); amounts tie out. The one break is
# the vendor text mismatch "Acme Corp" vs "Acme Corporation" (< 85% fuzzy) — correct.
assert result.summary["matched_pairs"] == 3, "all 3 invoices should match by key"
assert result.summary["unmatched_left"] == 0 and result.summary["unmatched_right"] == 0
for m in result.breaks:
    assert m.break_fields == ["vendor"], f"unexpected break fields: {m.break_fields}"
print(f"  matched all 3; {len(result.breaks)} vendor-only break(s) as expected")

data = api.export_workbook(result)
assert data[:2] == b"PK"
print(f"\nWorkbook bytes: {len(data)}")
print("\nALL ADVANCED-EXTRACTION ASSERTIONS PASSED")
