"""End-to-end: build files of every supported type in memory and reconcile."""
import io
import os
import sys
from decimal import Decimal

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pandas as pd
from financial_reconciliation import (ReconciliationPipeline, EngineConfig,
                                      UploadedDocument)


# ---- build sample files (bytes) in every format ----
def csv_bytes():
    return (b"Inv No,Vendor,Amount\n"
            b"INV-1001,Acme Corp.,\"1,200.50\"\n"
            b"INV-1002,Globex LLC,$3400\n")

def txt_bytes():  # pipe/markdown table, adds INV-1003 split for aggregation
    return ("| Inv No | Vendor | Amount |\n"
            "|--------|--------|--------|\n"
            "| INV-1003 | Initech | 900 |\n"
            "| INV-1003 | Initech | 100 |\n").encode()

def xlsx_bytes():  # right side, different column names
    df = pd.DataFrame({"Reference": ["INV-1001", "INV-1002"],
                       "Supplier": ["ACME CORP", "Globex LLC"],
                       "Total": ["1200.50", "3400.05"]})
    buf = io.BytesIO(); df.to_excel(buf, index=False, engine="openpyxl"); return buf.getvalue()

def docx_bytes():  # right side, INV-1003 aggregated target + a break
    import docx
    d = docx.Document()
    t = d.add_table(rows=1, cols=3)
    for i, h in enumerate(["Reference", "Supplier", "Total"]):
        t.rows[0].cells[i].text = h
    for ref, sup, tot in [("INV-1003", "Initech", "1000"), ("INV-1004", "Umbrella Company", "4999")]:
        c = t.add_row().cells
        c[0].text, c[1].text, c[2].text = ref, sup, tot
    buf = io.BytesIO(); d.save(buf); return buf.getvalue()

def pdf_bytes():   # left side extra: INV-1004 (will break vs docx) via a real ruled table
    import pdfplumber  # ensure lib present
    from reportlab_stub import make_pdf_table  # fallback below
    return make_pdf_table()


# minimal PDF with a ruled table using pdfplumber-friendly drawing via matplotlib
def pdf_bytes_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6, 2)); ax.axis("off")
    data = [["Inv No", "Vendor", "Amount"], ["INV-1004", "Umbrella Co", "5000"]]
    tbl = ax.table(cellText=data, loc="center", cellLoc="center")
    tbl.scale(1, 2)
    buf = io.BytesIO(); fig.savefig(buf, format="pdf"); plt.close(fig)
    return buf.getvalue()


pipe = ReconciliationPipeline()

left_docs = [
    UploadedDocument("ledger.csv", csv_bytes()),
    UploadedDocument("ledger_extra.txt", txt_bytes()),
    UploadedDocument("ledger_pdf.pdf", pdf_bytes_matplotlib()),
]
right_docs = [
    UploadedDocument("stmt.xlsx", xlsx_bytes()),
    UploadedDocument("stmt.docx", docx_bytes()),
]

left = pipe.parse_documents(left_docs)
right = pipe.parse_documents(right_docs)

print("LEFT columns :", pipe.columns(left))
print("RIGHT columns:", pipe.columns(right))
for e in left + right:
    for w in e.warnings:
        print("  warn:", e.document.filename, w.code.value, "-", w.message[:60])

config = EngineConfig.from_dict({
    "fields": [
        {"name": "invoice", "role": "key", "dtype": "text",
         "left_source": "Inv No", "right_source": "Reference"},
        {"name": "vendor", "role": "value", "dtype": "text",
         "left_source": "Vendor", "right_source": "Supplier", "text_fuzzy_threshold": 85},
        {"name": "amount", "role": "value", "dtype": "money",
         "left_source": "Amount", "right_source": "Total", "abs_tol": "0.10", "agg": "sum"},
    ],
    "matching": {"fuzzy_enabled": True, "fuzzy_threshold": 88,
                 "semantic_enabled": True, "semantic_threshold": 60,
                 "accept_threshold": 0.5},
    "norm": {"casefold_keys": True},
})

result = pipe.reconcile(left, right, config)
s = result.summary
print("\n=== SUMMARY ===")
for k in ("fuzzy_backend", "left_records", "right_records", "matched_pairs",
          "matched_exact", "matched_fuzzy_or_semantic", "reconciled", "breaks",
          "unmatched_left", "unmatched_right", "reconciliation_rate"):
    print(f"  {k}: {s[k]}")

print("\n=== FIELD VARIANCE ===")
for f in result.field_variance:
    print(f"  {f.field}: sum(L-R)={f.sum_left_minus_right} sum|diff|={f.sum_abs_difference} breaks={f.n_breaks}")

print("\n=== RECONCILED ===")
for m in result.reconciled:
    print(f"  {m.key_values['invoice']}: {m.match_type.value} conf={m.confidence:.2f} :: {m.explanation}")

print("\n=== BREAKS ===")
for m in result.breaks:
    print(f"  {m.key_values['invoice']}: broke {m.break_fields} :: {m.explanation}")

print("\n=== UNMATCHED ===")
print("  left :", [u.key_values['invoice'] for u in result.unmatched_left])
print("  right:", [u.key_values['invoice'] for u in result.unmatched_right])

# ---- assertions ----
recon = {m.key_values["invoice"] for m in result.reconciled}
brk = {m.key_values["invoice"] for m in result.breaks}
assert "inv-1001" in recon, "exact equal amount should reconcile"
assert "inv-1002" in recon, "within-tolerance (0.05<0.10) should reconcile"
assert "inv-1003" in recon, "TXT-aggregated (900+100=1000) vs DOCX 1000 should reconcile"
assert "inv-1004" in brk, "PDF 5000 vs DOCX 4999 should break on amount"
# money must be Decimal internally
amt = next(c.difference for m in result.reconciled if m.key_values["invoice"] == "inv-1002"
           for c in m.field_comparisons if c.field == "amount")
assert isinstance(amt, Decimal), "variance must be Decimal, not float"

# ---- export ----
from financial_reconciliation.exporters.workbook import WorkbookExporter
xlsx = WorkbookExporter().export(result)
assert xlsx[:2] == b"PK", "xlsx export should be a zip/xlsx"
print(f"\nxlsx export bytes: {len(xlsx)}")
print("\nALL ASSERTIONS PASSED")
