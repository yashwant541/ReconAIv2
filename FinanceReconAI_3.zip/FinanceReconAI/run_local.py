"""Run FinanceReconAI locally (outside Dataiku).

    python run_local.py         # serves http://127.0.0.1:5000

In Dataiku you do NOT use this file: paste webapp/backend.py into the Standard
web app's Python tab (Dataiku provides `app`) and the frontend files into the
HTML/CSS/JS tabs. This runner just supplies the same `app` object for local dev.
"""
from __future__ import annotations

import os
import sys

from flask import Flask, Response, send_from_directory

ROOT = os.path.dirname(os.path.abspath(__file__))
FRONTEND = os.path.join(ROOT, "webapp", "frontend")
sys.path.insert(0, ROOT)  # make `financial_reconciliation` importable

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FinanceReconAI</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/styles.css"></head><body>
{body}
<script src="/app.js"></script></body></html>"""


def build_app() -> Flask:
    app = Flask(__name__)

    @app.route("/")
    def index():
        with open(os.path.join(FRONTEND, "index.html"), encoding="utf-8") as f:
            return Response(PAGE.format(body=f.read()), mimetype="text/html")

    @app.route("/<path:fname>")
    def static_files(fname):
        if os.path.exists(os.path.join(FRONTEND, fname)):
            return send_from_directory(FRONTEND, fname)
        return ("not found", 404)

    # Register the backend routes against this app (Dataiku would provide `app`).
    with open(os.path.join(ROOT, "webapp", "backend.py"), encoding="utf-8") as f:
        code = compile(f.read(), "backend.py", "exec")
    exec(code, {"app": app, "__name__": "backend"})
    return app


app = build_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    print(f"FinanceReconAI running at http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=False)
