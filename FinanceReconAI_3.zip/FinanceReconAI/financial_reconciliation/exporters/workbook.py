"""Export a ReconciliationResult to a multi-sheet XLSX workbook (bytes)."""
from __future__ import annotations

import io

import pandas as pd

from ..models.results import ReconciliationResult
from .serialize import _match_row, _unmatched_row, _val


class WorkbookExporter:
    def export(self, result: ReconciliationResult) -> bytes:
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as xw:
            pd.DataFrame([result.summary]).to_excel(xw, sheet_name="summary", index=False)
            pd.DataFrame([{
                "field": f.field, "dtype": f.dtype,
                "sum_left_minus_right": _val(f.sum_left_minus_right),
                "sum_abs_difference": _val(f.sum_abs_difference),
                "n_breaks": f.n_breaks} for f in result.field_variance]
            ).to_excel(xw, sheet_name="field_variance", index=False)
            _sheet(xw, "breaks", [_match_row(m) for m in result.breaks])
            _sheet(xw, "reconciled", [_match_row(m) for m in result.reconciled])
            _sheet(xw, "unmatched_left", [_unmatched_row(u) for u in result.unmatched_left])
            _sheet(xw, "unmatched_right", [_unmatched_row(u) for u in result.unmatched_right])
        buf.seek(0)
        return buf.getvalue()


def _sheet(xw, name: str, rows) -> None:
    df = pd.DataFrame(rows) if rows else pd.DataFrame({"(empty)": []})
    df.to_excel(xw, sheet_name=name, index=False)
