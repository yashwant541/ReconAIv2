# FinanceReconAI

Reconcile financial **tables against tables** across mixed documents. Upload
PDF, DOCX, Excel, CSV or TXT tables on a **left** and a **right** side; the
engine extracts tables, auto-detects structure, matches line items, computes
variance, and exports a workbook. Everything runs **in memory** — nothing is
stored unless you export.

The engine is a **framework-free Python library**; the web app is a thin layer
on top. It's designed to run inside **Dataiku** (Standard web app) or locally.

---

## The four steps (and where each lives as a library function)

Every step is a plain function in `financial_reconciliation/api.py`, so you can
call any of them independently or wire new features around them.

**1 — Extract tables** (headers can start on *any* row; multiple tables per sheet)
```python
from financial_reconciliation import api
ext   = api.extract_tables("statement.xlsx", data)        # -> ExtractionResult
sheets = api.list_sheets("statement.xlsx", data)          # for a sheet picker
ext   = api.extract_tables("statement.xlsx", data, sheets=["Q1"])
```

**2 — Structure into key/value pairs** (profile columns, auto-map both sides)
```python
profiles  = api.profile_side([ext])                        # type + key/value role per column
suggested = api.suggest_mapping([left_ext], [right_ext])   # cross-side field mapping
config    = EngineConfig.from_dict({"fields": suggested})
kv        = api.to_key_value_records([left_ext], config, Side.LEFT)  # (keys) -> (values)
```

**3 — Match & compute variance** (exact + fuzzy + semantic, per-field tolerance)
```python
result = api.reconcile([left_ext], [right_ext], config)
#   result.reconciled / .breaks / .unmatched_left / .unmatched_right / .field_variance
```

**4 — Export**
```python
xlsx_bytes = api.export_workbook(result)   # summary, variance, breaks, reconciled, unmatched
```

Output rows are laid out **key · left value · right value · difference · ok?**
for every value field, alongside the match type, confidence and explanation.

---

## Architecture

```
financial_reconciliation/          framework-free engine
  models/        money (Decimal), documents, results, enums
  config/        typed EngineConfig / FieldConfig / MatchingConfig
  parsers/       csv · txt · excel · docx · pdf  -> uniform ExtractionResult
  extraction/    grids · header_detection · table_detection · profiling
  normalization/ type coercion + key aggregation -> CanonicalRecord
  matching/      similarity · semantic (TF-IDF) · blocking · matcher
  reconciliation/variance + tolerance + categorization
  exporters/     json serialize · xlsx workbook
  pipeline.py    orchestration     api.py  public functional API
webapp/
  backend.py     Flask routes (Dataiku provides `app`)
  frontend/      index.html · styles.css · app.js  (4-step SPA)
run_local.py     local dev server (supplies `app`, serves frontend)
```

**Money is `decimal.Decimal` everywhere** — never float — so rounding never
manufactures phantom variances. Parsers take `(filename, bytes)` only; no paths,
no temp files. The `ReconciliationSession` is an immutable accumulator: each
stage returns a new session rather than mutating shared state.

---

## Run it

**Locally**
```bash
pip install -r requirements.txt
python run_local.py            # http://127.0.0.1:5000
```

**In Dataiku** (Standard web app): paste `webapp/backend.py` into the Python
tab (Dataiku supplies the `app` object — do not add Flask to the code env),
put `frontend/index.html|styles.css|app.js` into the HTML/CSS/JS tabs, and add
the `financial_reconciliation` package to the project libraries. The engine has
no Dataiku dependency, so it's unit-testable outside the platform.

> **On "no Flask":** the *engine* imports no web framework. A Dataiku Standard
> web app's backend *is* Flask, but the platform owns it. If you'd rather avoid
> Flask entirely, the same engine drops into a **Dash** web app unchanged —
> only `webapp/` would be swapped.

**Tests**
```bash
python tests/test_end_to_end.py         # all 5 formats -> reconcile -> export
python tests/test_advanced_extraction.py # offset headers, multi-table, auto-map
python tests/test_backend_http.py        # full web layer over HTTP
```

---

## Advanced features

**Built in**
- **Smart header detection** — finds the real header row even behind title/preamble rows (scores header-likeness vs data-likeness).
- **Multi-table region detection** — one sheet/page can hold several tables (split on blank rows/columns); each gets its own header.
- **Column profiling** — infers `money / numeric / date / text` and suggests **key vs value** roles from name hints + cardinality.
- **Auto field-mapping across sides** — aligns differently-named columns (`Invoice`↔`Reference`, `Amount`↔`Total`) using **value overlap (Jaccard) + a financial synonym dictionary + name similarity**, not names alone.
- **Explainable matching** — exact key → fuzzy (rapidfuzz/difflib) → **semantic TF-IDF** (scikit-learn, with a pure-numpy fallback), combined into a weighted confidence with a per-match "why it matched" reason.
- **Blocking** — buckets records before fuzzy/semantic scoring to avoid O(n·m) on large inputs.
- **Aggregating keys** — many left rows summing to one right row reconcile (`sum/mean/min/max/first/last/count` per field).
- **Tolerances** — absolute + relative per money field, day-window for dates, fuzzy threshold for text.
- **Robust PDF** — tries ruled-line and whitespace strategies; flags scanned pages instead of inventing rows.

**Recommended next (clean extension points already in place)**
- **OCR** for scanned PDFs (Tesseract) behind the existing `SCANNED_PDF` signal.
- **Multi-currency** normalization + FX rate provider before variance.
- **Learned matching** — train a classifier on confirmed matches to tune strategy weights.
- **Many-to-many split/merge detection** (subset-sum) for partial payments and netting.
- **Persisted ontology** — promote the in-code synonym seed to a versioned YAML the business can edit.
- **Interactive break triage** — accept/reject matches in the UI and export an audit trail.

---

*In-memory only. No data is persisted server-side; parsed documents drop on
session expiry, `/finish`, or restart.*

---

## Admin, references & synonyms

**Admin login.** The **Admin** page signs in with a username + password verified
server-side. Set credentials in `financial_reconciliation/auth.py` or via env:
`FINRECON_ADMIN_USER`, `FINRECON_ADMIN_PASSWORD` (defaults `admin` /
`change-me-please` — change them). This is a minimal gate, not production auth;
for a real deployment use Dataiku's built-in user auth / SSO.

**Reference library.** Admins upload **pre-processed documents** (the tidy
`[dims…, Value]` xlsx/json) into a folder-backed library; users then pick one
from a dropdown on the Upload page and reconcile against it. Point the library
at a **Dataiku managed folder** with `FINRECON_LIBRARY=/path/to/managed/folder`
(defaults to `./reference_library`, which ships pre-seeded with the SCB Q1'26
reference). Admins can also **download** the tidy processed workbook for any
uploaded file without saving it.

**Synonyms.** Admins upload a global synonyms list (JSON/CSV/TXT) that is applied
to all matching (e.g. `Non-Interest Income, NII, NII Islamic Banking` collapse to
one concept). Users can also upload a per-session list that merges on top.

**Tidy/long + cleanup toggles** (Matching page): "Reshape to tidy/long" melts
wide tables so a fresh document lines up with the references cell-by-cell (auto-on
when a reference is selected); "Remove non-English characters" strips non-Latin
script from keys before matching.

### How the modules connect
`extraction/pdf_financial.py` (coordinate-based PDF tables) → `parsers/pdf_parser.py`
→ upload. `extraction/reshape.py` (wide→long) → `api.melt_extraction` → the melt
toggle. `ontology.py` → `/upload_synonyms` + `/admin/synonyms/save` → matching.
`reference_library.py` → `/reference/*` + `/admin/reference/*` → the dropdown.
`exporters/processed_workbook.py` → `/admin/reference/download`. `auth.py` →
`/admin/login` gates every admin action.
