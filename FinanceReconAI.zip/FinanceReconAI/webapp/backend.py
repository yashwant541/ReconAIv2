"""Web backend for FinanceReconAI.

Deploy into a Dataiku *Standard* web app's Python tab (Dataiku provides `app`),
or run locally via run_local.py which supplies `app`. The engine is
framework-free; this is the only web-aware layer. No disk persistence — parsed
documents and the last result live in an in-memory, TTL'd store.
"""
from __future__ import annotations

import io
import os
import threading
import time
import uuid
from typing import Any, Dict

from flask import jsonify, request, send_file

from financial_reconciliation import api
from financial_reconciliation.config.settings import EngineConfig
from financial_reconciliation.matching.similarity import BACKEND
from financial_reconciliation.models.documents import UploadedDocument
from financial_reconciliation.models.results import ReconciliationSession
from financial_reconciliation.reference_library import ReferenceLibrary, admin_ok

SESSION_TTL_SECONDS = 60 * 60
MAX_UPLOAD_MB = 100
_LIBRARY = ReferenceLibrary(os.environ.get("FINRECON_LIBRARY", "./reference_library"))

_SESSIONS: Dict[str, Dict[str, Any]] = {}
_LOCK = threading.Lock()


def _evict() -> None:
    cutoff = time.time() - SESSION_TTL_SECONDS
    with _LOCK:
        for sid in [s for s, v in _SESSIONS.items() if v["ts"] < cutoff]:
            _SESSIONS.pop(sid, None)


def _get(sid: str) -> Dict[str, Any]:
    _evict()
    with _LOCK:
        s = _SESSIONS.get(sid)
        if s is None:
            raise KeyError("Unknown or expired session")
        s["ts"] = time.time()
        return s


def _tables_meta(extractions) -> list:
    out = []
    for e in extractions:
        for t in e.document.tables:
            out.append({"id": api.table_id(e.document.filename, t.name),
                        "file": e.document.filename, "table": t.name,
                        "columns": t.columns, "rows": t.row_count})
    return out


@app.route("/session", methods=["POST"])
def create_session():
    sid = uuid.uuid4().hex
    with _LOCK:
        _SESSIONS[sid] = {"ts": time.time(),
                          "session": ReconciliationSession(session_id=sid),
                          "result": None, "ontology": None}
    return jsonify({"session_id": sid, "fuzzy_backend": BACKEND})


@app.route("/upload", methods=["POST"])
def upload():
    sid = request.form.get("sid", "")
    side = request.form.get("side", "")
    if side not in ("left", "right"):
        return jsonify({"error": "side must be 'left' or 'right'"}), 400
    try:
        store = _get(sid)
    except KeyError as e:
        return jsonify({"error": str(e)}), 404

    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "no files provided"}), 400

    docs = []
    for fs in files:
        data = fs.read()
        if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
            return jsonify({"error": f"{fs.filename} exceeds {MAX_UPLOAD_MB} MB"}), 400
        docs.append(UploadedDocument(fs.filename, data))

    try:
        extractions = api.extract_many(docs)
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": f"parse failed: {e}"}), 400

    warnings = [{**w.as_dict(), "file": e.document.filename}
                for e in extractions for w in e.warnings]
    session = store["session"].with_extractions(side, extractions)
    store["session"] = session
    side_ext = session.left_extractions if side == "left" else session.right_extractions

    return jsonify({"side": side, "warnings": warnings,
                    "tables": _tables_meta(extractions),
                    "side_columns": session.columns(side),
                    "side_tables": _tables_meta(side_ext),
                    "side_file_count": len(side_ext)})


@app.route("/suggest_mapping", methods=["POST"])
def suggest_mapping():
    body = request.get_json(force=True)
    try:
        store = _get(body.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    s = store["session"]
    if not s.left_extractions or not s.right_extractions:
        return jsonify({"error": "upload files on both sides first"}), 400
    fields = api.suggest_mapping(list(s.left_extractions), list(s.right_extractions))
    left_profiles = [p.as_dict() for p in api.profile_side(list(s.left_extractions))]
    right_profiles = [p.as_dict() for p in api.profile_side(list(s.right_extractions))]
    return jsonify({"fields": fields, "left_profiles": left_profiles,
                    "right_profiles": right_profiles})


@app.route("/reset_side", methods=["POST"])
def reset_side():
    body = request.get_json(force=True)
    try:
        store = _get(body.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    side = body.get("side")
    if side in ("left", "right"):
        store["session"] = store["session"].cleared_side(side)
    return jsonify({"ok": True})


@app.route("/reconcile", methods=["POST"])
def reconcile():
    body = request.get_json(force=True)
    try:
        store = _get(body.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    s = store["session"]
    if not s.left_extractions or not s.right_extractions:
        return jsonify({"error": "upload files on both sides first"}), 400
    inc_l = set(body["included_left"]) if body.get("included_left") else None
    inc_r = set(body["included_right"]) if body.get("included_right") else None
    try:
        config = EngineConfig.from_dict(body)
        result = api.reconcile(list(s.left_extractions), list(s.right_extractions),
                               config, inc_l, inc_r, ontology=store.get("ontology"))
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": f"reconciliation failed: {e}"}), 400
    store["result"] = result
    return jsonify(api.result_to_dict(result))


@app.route("/export", methods=["GET"])
def export():
    try:
        store = _get(request.args.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    if store.get("result") is None:
        return jsonify({"error": "run a reconciliation first"}), 400
    data = api.export_workbook(store["result"])
    return send_file(io.BytesIO(data), as_attachment=True,
                     download_name="reconciliation.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/finish", methods=["POST"])
def finish():
    body = request.get_json(force=True)
    with _LOCK:
        _SESSIONS.pop(body.get("sid", ""), None)
    return jsonify({"ok": True})


@app.route("/upload_synonyms", methods=["POST"])
def upload_synonyms():
    sid = request.form.get("sid", "")
    try:
        store = _get(sid)
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    fs = request.files.get("file")
    if fs is None:
        return jsonify({"error": "no file"}), 400
    try:
        onto = api.load_ontology(fs.filename, fs.read())
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": f"could not read synonyms: {e}"}), 400
    store["ontology"] = onto
    return jsonify({"ok": True, "aliases": onto.size, "concepts": len(onto.groups())})


@app.route("/reference/list", methods=["GET"])
def reference_list():
    return jsonify({"references": _LIBRARY.list()})


@app.route("/reference/use", methods=["POST"])
def reference_use():
    body = request.get_json(force=True)
    try:
        store = _get(body.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    side = body.get("side")
    if side not in ("left", "right"):
        return jsonify({"error": "side must be left/right"}), 400
    try:
        processed = _LIBRARY.get(body.get("ref_id", ""))
        ext = api.load_processed(processed)
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": f"reference not found: {e}"}), 404
    store["session"] = store["session"].with_extractions(side, [ext])
    return jsonify({"ok": True, "side": side,
                    "tables": _tables_meta([ext]),
                    "side_columns": store["session"].columns(side)})


@app.route("/admin/reference/save", methods=["POST"])
def admin_reference_save():
    """Admin-gated: save a side's parsed tables as a reusable reference."""
    body = request.get_json(force=True)
    if not admin_ok(body.get("token")):
        return jsonify({"error": "admin token required/invalid"}), 403
    try:
        store = _get(body.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    side = body.get("side", "left")
    exts = list(store["session"].left_extractions if side == "left"
                else store["session"].right_extractions)
    if not exts:
        return jsonify({"error": "no tables on that side"}), 400
    processed = api.export_processed(exts, body.get("name", "reference"))
    ref_id = _LIBRARY.save(body.get("ref_id") or body.get("name", "reference"), processed)
    return jsonify({"ok": True, "ref_id": ref_id, "tables": len(processed["tables"])})
