"""Split a grid into one or more table regions and materialize FinancialTables.

A single sheet may hold several stacked/side-by-side tables separated by blank
rows or columns; each region gets its own header detection.
"""
from __future__ import annotations

from typing import List

from ..models.documents import FinancialRecord, FinancialTable
from .grids import Grid, normalize_grid, row_is_empty, trim
from .header_detection import build_columns, detect_header_row


def _split_rows(grid: Grid) -> List[Grid]:
    """Split on runs of fully-empty rows."""
    blocks, cur = [], []
    for row in grid:
        if row_is_empty(row):
            if cur:
                blocks.append(cur); cur = []
        else:
            cur.append(row)
    if cur:
        blocks.append(cur)
    return blocks


def _split_cols(block: Grid) -> List[Grid]:
    """Split a row-block on fully-empty columns (side-by-side tables)."""
    block = normalize_grid(block)
    width = len(block[0]) if block else 0
    empty = [all((c is None or str(c).strip() == "") for c in (r[j] for r in block))
             for j in range(width)]
    groups, cur = [], []
    for j in range(width):
        if empty[j]:
            if cur:
                groups.append(cur); cur = []
        else:
            cur.append(j)
    if cur:
        groups.append(cur)
    if len(groups) <= 1:
        return [block]
    return [[[r[j] for j in g] for r in block] for g in groups]


def find_table_regions(grid: Grid, min_rows: int = 2, min_cols: int = 2) -> List[Grid]:
    """Return trimmed sub-grids, each a candidate table."""
    regions: List[Grid] = []
    for row_block in _split_rows(grid):
        for region in _split_cols(row_block):
            t = trim(region)
            if len(t) >= min_rows and (len(t[0]) if t else 0) >= min_cols:
                regions.append(t)
    return regions


def region_to_table(region: Grid, source_file: str, table_name: str) -> FinancialTable:
    h = detect_header_row(region)
    columns = build_columns(region[h])
    records: List[FinancialRecord] = []
    for idx, row in enumerate(region[h + 1:]):
        row = list(row) + [None] * (len(columns) - len(row))
        values = {columns[j]: row[j] for j in range(len(columns))}
        records.append(FinancialRecord(values=values, source_file=source_file,
                                       table_name=table_name, row_index=idx))
    return FinancialTable(name=table_name, columns=columns,
                          records=records, source_file=source_file)


def tables_from_grid(grid: Grid, source_file: str, base_name: str) -> List[FinancialTable]:
    """Full pipeline: grid -> regions -> tables (multi-table aware)."""
    regions = find_table_regions(grid)
    if not regions:
        return []
    if len(regions) == 1:
        return [region_to_table(regions[0], source_file, base_name)]
    return [region_to_table(r, source_file, f"{base_name}#{i + 1}")
            for i, r in enumerate(regions)]
