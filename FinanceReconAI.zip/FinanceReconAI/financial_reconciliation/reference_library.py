"""A library of pre-processed 'reference' documents to reconcile against.

Each entry is a processed-document JSON (see api.export_processed) stored in a
folder. In Dataiku this folder is a managed folder; locally it's a directory.
Users pick a reference (e.g. "SCB Q1'26") from a dropdown and reconcile their
upload against it.

Admin note: updating the library and the synonym list is gated by a shared
token here for the prototype. This is NOT real authentication — production
deployments should use Dataiku's built-in user auth / SSO and permissions, and
treat this token only as a second, minimal guard.
"""
from __future__ import annotations

import json
import os
import re
from typing import Dict, List, Optional

_SAFE = re.compile(r"[^A-Za-z0-9._-]+")


def _slug(name: str) -> str:
    return _SAFE.sub("_", name.strip()).strip("_") or "reference"


class ReferenceLibrary:
    def __init__(self, root: str) -> None:
        self.root = root
        os.makedirs(root, exist_ok=True)

    def list(self) -> List[Dict]:
        out = []
        for fn in sorted(os.listdir(self.root)):
            if not fn.endswith(".json"):
                continue
            try:
                obj = self._read(fn)
                out.append({"id": fn[:-5], "source": obj.get("source", fn[:-5]),
                            "tables": len(obj.get("tables", []))})
            except Exception:  # noqa: BLE001
                continue
        return out

    def get(self, ref_id: str) -> Dict:
        return self._read(f"{_slug(ref_id)}.json")

    def save(self, ref_id: str, processed: Dict) -> str:
        fn = f"{_slug(ref_id)}.json"
        with open(os.path.join(self.root, fn), "w", encoding="utf-8") as f:
            json.dump(processed, f, ensure_ascii=False, indent=2)
        return fn[:-5]

    def delete(self, ref_id: str) -> bool:
        path = os.path.join(self.root, f"{_slug(ref_id)}.json")
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def _read(self, fn: str) -> Dict:
        with open(os.path.join(self.root, fn), encoding="utf-8") as f:
            return json.load(f)


def admin_ok(token: Optional[str]) -> bool:
    """Minimal admin gate. Set FINRECON_ADMIN_TOKEN in the environment.

    Returns False if no token is configured (locked by default). This is a
    guard, not real authentication — see the module docstring.
    """
    expected = os.environ.get("FINRECON_ADMIN_TOKEN")
    return bool(expected) and token == expected
