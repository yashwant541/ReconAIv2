"""PDF parser (highest-risk format).

Extracts tables per page using two pdfplumber strategies and keeps whichever
yields more structure:
  * "lines"  -> ruled/lattice tables (explicit borders)
  * "text"   -> whitespace-aligned/borderless tables
Detects image-only (scanned) pages -> SCANNED_PDF warning (OCR out of scope v1),
handles encrypted files, and is import-guarded.
"""
from __future__ import annotations

import io
from typing import List

from ..extraction.table_detection import tables_from_grid
from ..models.documents import (ExtractionResult, FinancialDocument, FinancialTable,
                                 ParseWarning)
from ..models.enums import FileFormat, Severity, WarningCode

try:
    import pdfplumber
    _PDF_OK = True
except Exception:  # pragma: no cover
    _PDF_OK = False

_LINES = {"vertical_strategy": "lines", "horizontal_strategy": "lines"}
_TEXT = {"vertical_strategy": "text", "horizontal_strategy": "text",
         "snap_tolerance": 4, "join_tolerance": 4}


class PdfParser:
    formats = [FileFormat.PDF]

    def parse(self, filename: str, data: bytes) -> ExtractionResult:
        if not _PDF_OK:
            return _lib_missing(filename)
        warnings: List[ParseWarning] = []
        tables: List[FinancialTable] = []
        try:
            pdf = pdfplumber.open(io.BytesIO(data))
        except Exception as exc:  # noqa: BLE001 (includes encrypted)
            warnings.append(ParseWarning(WarningCode.ENCRYPTED_FILE,
                                         f"Could not open {filename}: {exc}", Severity.ERROR))
            return ExtractionResult(FinancialDocument(filename, FileFormat.PDF, []), warnings)

        page_count = 0
        with pdf:
            page_count = len(pdf.pages)
            for p_idx, page in enumerate(pdf.pages):
                text = (page.extract_text() or "").strip()
                grids = self._best_tables(page)
                if not text and not grids:
                    warnings.append(ParseWarning(
                        WarningCode.SCANNED_PDF,
                        f"Page {p_idx + 1} of {filename} has no extractable text "
                        "(likely scanned). OCR is not enabled.",
                        Severity.WARNING, {"page": p_idx + 1}))
                    continue
                for t_idx, grid in enumerate(grids):
                    tables.extend(tables_from_grid(
                        grid, filename, f"page{p_idx + 1}_t{t_idx + 1}"))

        if not tables and not any(w.code == WarningCode.SCANNED_PDF for w in warnings):
            warnings.append(ParseWarning(WarningCode.NO_TABLES_FOUND,
                                         f"No tables detected in {filename}.", Severity.WARNING))
        doc = FinancialDocument(filename, FileFormat.PDF, tables,
                                metadata={"pages": page_count})
        return ExtractionResult(doc, warnings, {"tables": len(tables), "rows": doc.record_count})

    @staticmethod
    def _best_tables(page) -> List[list]:
        """Try lattice, then whitespace; keep the strategy with more cells."""
        best: List[list] = []
        best_cells = 0
        for settings in (_LINES, _TEXT):
            try:
                found = page.extract_tables(table_settings=settings) or []
            except Exception:  # noqa: BLE001
                found = []
            cells = sum(len(r) for g in found for r in g)
            if cells > best_cells:
                best, best_cells = found, cells
        return best


def _lib_missing(filename: str) -> ExtractionResult:
    w = ParseWarning(WarningCode.PARSER_LIBRARY_MISSING,
                     "pdfplumber is not installed in this code env; "
                     f"{filename} was skipped. Add 'pdfplumber' to requirements.",
                     Severity.ERROR)
    return ExtractionResult(FinancialDocument(filename, FileFormat.PDF, []), [w], {"rows": 0})
