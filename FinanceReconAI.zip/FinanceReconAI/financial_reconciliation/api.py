"""Public functional API — each pipeline step as a standalone function.

    Step 1  extract_tables / list_sheets      -> tables with detected headers
    Step 2  profile_side / suggest_mapping     -> auto key/value structure
            to_key_value_records               -> (keys) -> (values) per side
    Step 3  reconcile                          -> line/key match + variance
    Step 4  export_workbook                    -> downloadable .xlsx

These wrap the object-oriented engine so other apps can call any step in
isolation without touching the web layer.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Set

from .config.settings import EngineConfig
from .extraction.profiling import ColumnProfile, profile_column
from .mapping.auto_map import suggest_mapping as _suggest
from .models.documents import ExtractionResult, UploadedDocument
from .models.enums import Side
from .models.results import CanonicalRecord, ReconciliationResult
from .normalization.normalizer import Normalizer
from .parsers.base import default_factory
from .parsers.excel_parser import list_sheets as _list_sheets
from .pipeline import ReconciliationPipeline

_FACTORY = default_factory()
_PIPELINE = ReconciliationPipeline(_FACTORY)


# ---- Step 1: extraction --------------------------------------------------
def list_sheets(filename: str, data: bytes) -> List[str]:
    """Sheet names for an Excel workbook (for a sheet picker)."""
    return _list_sheets(filename, data)


def extract_tables(filename: str, data: bytes,
                   sheets: Optional[List[str]] = None) -> ExtractionResult:
    """Parse one file into tables with detected headers. `sheets` filters Excel."""
    parser = _FACTORY.for_filename(filename)
    if sheets is not None and hasattr(parser, "parse") and \
            parser.__class__.__name__ == "ExcelParser":
        return parser.parse(filename, data, sheets=sheets)  # type: ignore[call-arg]
    return parser.parse(filename, data)


def extract_many(docs: List[UploadedDocument]) -> List[ExtractionResult]:
    return _PIPELINE.parse_documents(docs)


def table_id(source_file: str, table_name: str) -> str:
    return f"{source_file}||{table_name}"


# ---- Step 2: profiling, mapping, key/value pairs -------------------------
def profile_side(extractions: List[ExtractionResult]) -> List[ColumnProfile]:
    """One profile per distinct column across a side's tables."""
    columns: List[str] = []
    for e in extractions:
        for c in e.all_columns():
            if c not in columns:
                columns.append(c)
    records = [r for e in extractions for r in e.all_records()]
    return [profile_column(c, [r.values.get(c) for r in records]) for c in columns]


def suggest_mapping(left: List[ExtractionResult],
                    right: List[ExtractionResult]) -> List[Dict]:
    """Auto-suggest canonical fields aligning both sides' columns."""
    return _suggest(profile_side(left), profile_side(right))


def to_key_value_records(extractions: List[ExtractionResult], config: EngineConfig,
                         side: Side) -> List[CanonicalRecord]:
    """Step 2 made explicit: rows -> (key columns) -> (value columns), aggregated."""
    config.validate()
    records = [r for e in extractions for r in e.all_records()]
    return Normalizer(config).canonicalize(records, side)


# ---- Step 3: reconcile ---------------------------------------------------
def reconcile(left: List[ExtractionResult], right: List[ExtractionResult],
              config: EngineConfig,
              included_left: Optional[Set[str]] = None,
              included_right: Optional[Set[str]] = None) -> ReconciliationResult:
    return _PIPELINE.reconcile(left, right, config, included_left, included_right)


# ---- Step 4: export ------------------------------------------------------
def export_workbook(result: ReconciliationResult) -> bytes:
    from .exporters.workbook import WorkbookExporter
    return WorkbookExporter().export(result)


def result_to_dict(result: ReconciliationResult, cap: int = 250) -> Dict:
    from .exporters.serialize import result_to_dict as _r2d
    return _r2d(result, cap)
